Things I have added
- A gun the follows the mouse
- Clicking the left mouse button will shoot projectiles
- Enemies can be destroyed with projectiles
- Destroyable walls
- An enemy that will fire projectiles at the player 